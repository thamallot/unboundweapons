package org.minitype.mcmodstest;

import com.mojang.serialization.Codec;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_7923;
import net.minecraft.class_9331;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MegaWeapons implements ModInitializer {
    public static final class_2960 DASH_PACKET =
            class_2960.method_60655("mega_weapons", "dash");
    // =========================================================
    // CUSTOM SWORD LEVEL COMPONENT
    // =========================================================

    public static final class_9331<Integer> MEGA_LEVEL = class_2378.method_10230(
            class_7923.field_49658,
            class_2960.method_60655("mega_weapons", "level"),
            class_9331.<Integer>method_57873()
                    .method_57881(Codec.INT)
                    .method_57880()
    );

    // =========================================================
    // COMBO TRACKING
    // =========================================================

    private final Map<UUID, Integer> comboCounter = new HashMap<>();
    private final Map<UUID, Long> lastHitTime = new HashMap<>();

    // Combo resets after 3 seconds
    private static final long COMBO_RESET_TIME = 3000;

    // =========================================================
    // IMPACT TYPES
    // =========================================================

    public enum ImpactType {
        BLACK_FLASH,
        PARALYZE
    }

    @Override
    public void onInitialize() {

        System.out.println("Mega Weapons Initialized!");


        // =====================================================
// USE ITEM CALLBACK
// =====================================================

        UseItemCallback.EVENT.register((player, world, hand) -> {

            class_1799 stack = player.method_5998(hand);

            if (world.method_8608()) {
                return class_1269.field_5811;
            }

            // =================================================
            // AXE LOGIC
            // =================================================

            if (stack.method_7909() instanceof net.minecraft.class_1743) {

                ((class_3218) world).method_65096(
                        class_2398.field_11204,
                        player.method_23317(),
                        player.method_23318(),
                        player.method_23321(),
                        3,
                        0.2,
                        0.1,
                        0.2,
                        0.02
                );

                return class_1269.field_21466;
            }

            // =================================================
            // SWORD LOGIC
            // =================================================

            if (
                    stack.method_31574(class_1802.field_8091) ||
                            stack.method_31574(class_1802.field_8528) ||
                            stack.method_31574(class_1802.field_8371) ||
                            stack.method_31574(class_1802.field_8845) ||
                            stack.method_31574(class_1802.field_8802) ||
                            stack.method_31574(class_1802.field_22022)
            ) {

                // =============================================
                // UPGRADE SYSTEM
                // Sneak + Right Click
                // =============================================

                if (player.method_5715()) {

                    boolean upgraded = false;

                    for (int i = 0; i < player.method_31548().method_5439(); i++) {

                        class_1799 invStack = player.method_31548().method_5438(i);

                        if (invStack.method_31574(class_1802.field_8397)) {

                            invStack.method_7934(1);
                            upgraded = true;
                            break;
                        }
                    }

                    if (upgraded) {

                        int currentLevel = stack.method_58695(MEGA_LEVEL, 0);

                        stack.method_57379(MEGA_LEVEL, currentLevel + 1);

                        player.method_7353(
                                class_2561.method_43470("§6§lSWORD UPGRADED TO LEVEL " + (currentLevel + 1)),
                                true
                        );

                        world.method_43128(
                                null,
                                player.method_23317(),
                                player.method_23318(),
                                player.method_23321(),
                                class_3417.field_14559,
                                class_3419.field_15248,
                                1.0f,
                                1.2f
                        );

                    } else {

                        player.method_7353(
                                class_2561.method_43470("§cYou need a Mega Token (Gold Nugget)!"),
                                true
                        );
                    }

                    return class_1269.field_5812;
                }

                return class_1269.field_5811;
            }

            return class_1269.field_5811;
        });

        // =====================================================
        // ATTACK CALLBACK
        // =====================================================

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {

            if (!world.method_8608() && entity instanceof class_1309 target) {

                class_1799 stack = player.method_5998(hand);
                class_3218 sWorld = (class_3218) world;

                // =============================================
                // SWORD COMBO SYSTEM
                // =============================================

                if (
                        stack.method_31574(class_1802.field_8091) ||
                                stack.method_31574(class_1802.field_8528) ||
                                stack.method_31574(class_1802.field_8371) ||
                                stack.method_31574(class_1802.field_8845) ||
                                stack.method_31574(class_1802.field_8802) ||
                                stack.method_31574(class_1802.field_22022)
                ) {

                    UUID uuid = player.method_5667();

                    long now = System.currentTimeMillis();

                    long lastHit = lastHitTime.getOrDefault(uuid, 0L);

                    int hits;

                    // Reset combo if too slow
                    if (now - lastHit > COMBO_RESET_TIME) {
                        hits = 1;
                    } else {
                        hits = comboCounter.getOrDefault(uuid, 0) + 1;
                    }

                    lastHitTime.put(uuid, now);

                    // BLACK FLASH
                    if (hits >= 4) {

                        triggerImpact(
                                player,
                                target,
                                sWorld,
                                ImpactType.BLACK_FLASH
                        );

                        comboCounter.put(uuid, 0);

                    } else {

                        comboCounter.put(uuid, hits);

                        player.method_7353(
                                class_2561.method_43470("§7Combo: §e" + hits),
                                true
                        );
                    }
                }

                // =============================================
                // AXE PARALYZE
                // Sneak + Attack
                // =============================================

                if (stack.method_7909() instanceof net.minecraft.class_1743
                        && player.method_5715()) {

                    triggerImpact(
                            player,
                            target,
                            sWorld,
                            ImpactType.PARALYZE
                    );
                }
            }

            return class_1269.field_5811;
        });

        // =====================================================
        // TOKEN ECONOMY
        // =====================================================

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {

            if (damageSource.method_5529() instanceof class_3222 player) {

                class_1799 nugget = new class_1799(class_1802.field_8397);

                // Try inventory first
                if (!player.method_31548().method_7394(nugget)) {
                    player.method_7328(nugget, false);
                }

                player.method_7353(
                        class_2561.method_43470("§e§l+1 MEGA TOKEN"),
                        false
                );

                player.method_5783(
                        class_3417.field_14627,
                        1.0f,
                        1.0f
                );
            }
        });

        // =====================================================
        // MEMORY CLEANUP
        // =====================================================

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {

            UUID uuid = handler.field_14140.method_5667();

            comboCounter.remove(uuid);
            lastHitTime.remove(uuid);
        });
    }

    // =========================================================
    // IMPACT HANDLER
    // =========================================================

    private void triggerImpact(
            net.minecraft.class_1657 player,
            class_1309 target,
            class_3218 world,
            ImpactType type
    ) {

        // Shared effects
        world.method_65096(
                class_2398.field_38908,
                target.method_23317(),
                target.method_23318() + 1,
                target.method_23321(),
                1,
                0,
                0,
                0,
                0
        );

        player.method_5783(
                class_3417.field_38830,
                1.0f,
                1.0f
        );

        // =====================================================
        // PARALYZE
        // =====================================================

        if (type == ImpactType.PARALYZE) {

            target.method_6092(
                    new class_1293(
                            class_1294.field_5909,
                            60,
                            255
                    )
            );

            player.method_7353(
                    class_2561.method_43470("§4§lARMOR PARALYZED!"),
                    true
            );
        }

        // =====================================================
        // BLACK FLASH
        // =====================================================

        if (type == ImpactType.BLACK_FLASH) {

            target.method_6005(
                    2.0,
                    player.method_23317() - target.method_23317(),
                    player.method_23321() - target.method_23321()
            );

            player.method_7353(
                    class_2561.method_43470("§0§l> §c§lBLACK FLASH §0§l<"),
                    true
            );
        }
    }
}