package org.minitype.mcmodstest.client;

import net.fabricmc.api.ClientModInitializer;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class MegaWeaponsClient implements ClientModInitializer {

    private static class_304 dashKey;
    private static long lastDashTime = 0;

    @Override
    public void onInitializeClient() {

        dashKey = KeyBindingHelper.registerKeyBinding(
                new class_304(
                        "key.mega_weapons.dash",
                        class_3675.class_307.field_1668,
                        GLFW.GLFW_KEY_R,
                        class_304.class_11900.method_74698(
                                class_2960.method_60655("mega_weapons", "mega_weapons")
                        )
                )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            while (dashKey.method_1436()) {

                class_310 mc = class_310.method_1551();

                if (mc.field_1724 == null) return;

                // Must sprint
                if (!mc.field_1724.method_5624()) return;

                // Must hold sword
                if (
                        !mc.field_1724.method_6047().method_31574(class_1802.field_8091) &&
                                !mc.field_1724.method_6047().method_31574(class_1802.field_8528) &&
                                !mc.field_1724.method_6047().method_31574(class_1802.field_8371) &&
                                !mc.field_1724.method_6047().method_31574(class_1802.field_8845) &&
                                !mc.field_1724.method_6047().method_31574(class_1802.field_8802) &&
                                !mc.field_1724.method_6047().method_31574(class_1802.field_22022)
                ) {
                    return;
                }

                // DASH COOLDOWN
                long now = System.currentTimeMillis();

                if (now - lastDashTime < 5000) {
                    return;
                }

                lastDashTime = now;

                // DASH LOGIC
                class_243 look = mc.field_1724.method_5720();

                class_243 dash = new class_243(
                        look.field_1352,
                        0,
                        look.field_1350
                ).method_1029().method_1021(1.5);

                mc.field_1724.method_5762(
                        dash.field_1352,
                        0.15,
                        dash.field_1350
                );


                // COOLDOWN ANIMATION
                mc.field_1724.method_7357().method_62835(
                        mc.field_1724.method_6047(),
                        100
                );
            }
        });
    }
}