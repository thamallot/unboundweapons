package org.minitype.mcmodstest;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2561;

import static net.minecraft.class_2170.method_9247;


public class Mcmodstest implements ModInitializer {

    @Override
    public void onInitialize() {
        System.out.println("Hello World Mod Initialized");

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(

                    method_9247("hello").executes(commandContext -> {
                        commandContext.getSource().method_45068(class_2561.method_43470("world!").method_27692(class_124.field_1075));
                        return 1;
                    })

            );
        });
    }
}
